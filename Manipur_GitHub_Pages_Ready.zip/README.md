# Manipur Obsidian Evidence Terminal

Ready for GitHub Pages. The website is fully contained in `index.html`.

## Publish
1. Create a new GitHub repository (for example `manipur-violence-terminal`).
2. Upload `index.html`, `.nojekyll`, and `README.md` to the repository root (not inside a folder).
3. In repository **Settings > Pages**, select **Deploy from a branch**.
4. Choose **main**, folder **/(root)**, then **Save**.
5. Once deployed, open `https://YOUR-USERNAME.github.io/manipur-violence-terminal/`.

The site needs no build step and no server-side application. External source links require internet access.

## Updating
Replace `index.html` in the repository and commit. GitHub Pages will redeploy automatically.

## Note
This is the standalone published dashboard. The separate source pack contains the editable datasets and build scripts.
